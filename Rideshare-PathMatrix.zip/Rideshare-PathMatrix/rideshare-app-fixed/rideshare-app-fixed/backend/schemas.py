"""
Data models for the Dynamic Ride Sharing system (Part B).

Everything is kept deliberately explicit (no hidden magic) so it maps
1:1 onto the vocabulary used in the project brief: pickup/drop,
flexibility margin, vehicle capacity, dynamic insertion.
"""

from __future__ import annotations
from typing import List, Optional, Literal
from pydantic import BaseModel, Field


class Point(BaseModel):
    lat: float
    lon: float
    label: Optional[str] = None


class SetupRequest(BaseModel):
    source: Point
    destination: Point
    capacity: int = Field(gt=0, description="Max passengers in the vehicle at once")


class NewRideRequest(BaseModel):
    pickup: Point
    drop: Point
    flexibility_km: float = Field(ge=0, description="Max extra km allowed for this rider (Delta_i)")


class Stop(BaseModel):
    """A single stop in the route: either a pickup or a drop for some request."""
    request_id: int
    kind: Literal["pickup", "drop"]
    point: Point


class RequestRecord(BaseModel):
    id: int
    pickup: Point
    drop: Point
    base_distance_km: float
    flexibility_km: float
    max_allowed_km: float
    accepted: bool = True


class RouteState(BaseModel):
    """Full snapshot of the current world, returned to the frontend after every change."""
    source: Optional[Point] = None
    destination: Optional[Point] = None
    capacity: int = 0
    requests: List[RequestRecord] = []
    stops: List[Stop] = []              # ordered pickups/drops between source and destination
    ordered_points: List[Point] = []    # source + stops + destination, for convenience
    passenger_counts: List[int] = []    # passenger count AT each point in ordered_points
    leg_distances_km: List[float] = []  # distance from ordered_points[i] to ordered_points[i+1]
    total_distance_km: float = 0.0
    route_geometry: List[List[float]] = []  # [[lat, lon], ...] actual road-following polyline
    last_insertion_cost_km: Optional[float] = None
    last_rejection_reason: Optional[str] = None
    last_insertion_runtime_ms: Optional[float] = None  # 2.7: "Runtime of the algorithm"
