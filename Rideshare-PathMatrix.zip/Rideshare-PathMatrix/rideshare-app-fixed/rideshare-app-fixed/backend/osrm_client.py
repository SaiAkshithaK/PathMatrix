"""
Thin client around the public OSRM demo server (router.project-osrm.org).

OSRM gives us real road distances instead of straight-line guesses, which
is what the brief's "Travel Distance: computed using maps" line calls for.

Two endpoints are used:
  - /table/v1/driving   -> full distance matrix between N points in ONE call.
                            This is what makes the insertion search fast: we
                            fetch the matrix once per new request, then reuse
                            it for every candidate insertion position.
  - /route/v1/driving    -> an actual road-following polyline for a specific
                            ordered sequence of points, used only to draw the
                            final route on the map.

NOTE: this hits a public demo server. For production / heavy use, run your
own OSRM instance (docker run -p 5000:5000 osrm/osrm-backend ...) and change
OSRM_BASE_URL below.
"""

import httpx
from typing import List, Tuple

OSRM_BASE_URL = "https://router.project-osrm.org"

# OSRM wants "lon,lat" ordering, not "lat,lon" -- easy to get backwards.
def _coord_str(lat: float, lon: float) -> str:
    return f"{lon},{lat}"


async def distance_matrix_km(points: List[Tuple[float, float]]) -> List[List[float]]:
    """
    Given a list of (lat, lon) points, return an NxN matrix of real road
    distances in kilometers, matrix[i][j] = distance from point i to point j.
    """
    coords = ";".join(_coord_str(lat, lon) for lat, lon in points)
    url = f"{OSRM_BASE_URL}/table/v1/driving/{coords}?annotations=distance"

    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.get(url)
        resp.raise_for_status()
        data = resp.json()

    if data.get("code") != "Ok":
        raise RuntimeError(f"OSRM table request failed: {data.get('message', data.get('code'))}")

    # OSRM returns distances in meters
    meters_matrix = data["distances"]
    return [[(d / 1000.0 if d is not None else float("inf")) for d in row] for row in meters_matrix]


async def route_geometry(points: List[Tuple[float, float]]) -> List[List[float]]:
    """
    Given an ORDERED list of (lat, lon) waypoints, return the actual
    road-following polyline as [[lat, lon], ...] for drawing on the map.
    """
    if len(points) < 2:
        return [[lat, lon] for lat, lon in points]

    coords = ";".join(_coord_str(lat, lon) for lat, lon in points)
    url = (
        f"{OSRM_BASE_URL}/route/v1/driving/{coords}"
        f"?overview=full&geometries=geojson"
    )

    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.get(url)
        resp.raise_for_status()
        data = resp.json()

    if data.get("code") != "Ok" or not data.get("routes"):
        # Fall back to straight lines between the waypoints rather than crashing
        return [[lat, lon] for lat, lon in points]

    coords_lonlat = data["routes"][0]["geometry"]["coordinates"]
    return [[lat, lon] for lon, lat in coords_lonlat]
