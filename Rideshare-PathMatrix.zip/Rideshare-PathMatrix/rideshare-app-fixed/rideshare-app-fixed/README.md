# Part B — Dynamic Ride Sharing with Flexible Routing

FastAPI backend + a single-file React/Leaflet dispatch console. Real road
distances and route geometry come from the public OSRM demo server, so an
internet connection is required when you run this.

## Run the backend

```bash
cd backend
python -m venv venv && source venv/bin/activate   # optional but recommended
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

The API is now live at `http://localhost:8000`. Interactive docs (auto-generated
by FastAPI) are at `http://localhost:8000/docs` — useful for testing the
algorithm with the exact numbers from the PDF example before touching the UI.

## Run the frontend

No build step. Just open `frontend/index.html` in a browser (double-click it,
or `python -m http.server` in the `frontend` folder and visit the URL). CORS
is already open on the backend for local development.

## How to use it

1. **Route Setup** — click "pick on map" for Source, click the map, then the
   same for Destination. Set vehicle capacity. Click **Initialize Route**.
2. **New Ride Request** — pick a Pickup and Drop point on the map, set a
   flexibility margin (km), and click **Insert Into Route**. The backend
   finds the cheapest feasible insertion position, or rejects the request if
   no position satisfies capacity or someone's flexibility margin — the
   reason is shown in the sidebar.
3. Watch the **Route Timeline** (left) and the amber polyline (map) update.
   Each node shows passenger count at that point and the road distance to
   the next stop, mirroring the "Passenger Count During Route" table style
   from the brief.

## Where each brief requirement lives

| Brief requirement | Implementation |
|---|---|
| Pickup-before-drop | Insertion always places drop after pickup (`algorithm.py`) |
| Flexibility margin `dist_i + Δ_i` | Re-checked for every existing + new request on every candidate (`algorithm.py::find_best_insertion`) |
| Vehicle capacity | `_passenger_ok` simulates passenger count at every stop |
| Dynamic updates without full recompute | Only the new pickup/drop are searched for insertion positions; existing stop order is preserved, not rebuilt |
| Real road distances | OSRM `/table` (matrix) and `/route` (geometry) — `osrm_client.py` |
| Runtime reporting | `time.perf_counter()` wraps the insertion call in `main.py` (currently logged; wire into the response if you want it on-screen) |
| Passenger count per step | `state.passenger_counts`, shown as the "pax" badge on each timeline node |

## Extending toward the bonus features

- **3D / animation**: swap the Leaflet polyline draw for an animated
  `L.polylineDecorator` arrow trail, or move to deck.gl / Mapbox GL for a
  tilted 3D camera.
- **Real-time traffic**: OSRM's demo server doesn't carry live traffic —
  point `OSRM_BASE_URL` at a self-hosted OSRM built with traffic-adjusted
  weights, or switch `osrm_client.py` to a provider that does (e.g. a
  traffic-aware routing API), keeping the same function signatures.
- **Scale/efficiency**: the current search is O(n²) insertion positions per
  request, each O(1) after one shared distance-matrix fetch — fine for a
  single vehicle. For a fleet, shard state per vehicle and pick the vehicle
  with the cheapest feasible insertion.

## Note on the OSRM demo server

`https://router.project-osrm.org` is a free public demo — fine for building
and demoing, but not for heavy load or production. If you hit rate limits or
want offline development, run your own:

```bash
docker run -t -i -p 5000:5000 -v "${PWD}:/data" osrm/osrm-backend osrm-routed --algorithm mld /data/your-region.osrm
```

then change `OSRM_BASE_URL` in `backend/osrm_client.py` to
`http://localhost:5000`.
