"""
FastAPI backend for Part B: Dynamic Ride Sharing with Flexible Routing.

Run with:
    uvicorn main:app --reload --port 8000

Endpoints:
    POST   /api/setup     -> define source, destination, vehicle capacity (resets state)
    POST   /api/requests   -> submit a new ride request; runs the dynamic insertion algorithm
    GET    /api/state      -> current route snapshot (for the frontend to render)
    POST   /api/reset      -> clear everything
"""

import time
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from schemas import SetupRequest, NewRideRequest, RouteState, RequestRecord, Point
import osrm_client
import algorithm

app = FastAPI(title="Dynamic Ride Sharing API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # relax for local dev; tighten before deploying
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory state. Fine for a single-vehicle demo/project; swap for a DB
# or per-vehicle store if you extend this to a fleet.
state = RouteState()
_next_request_id = 1


async def _refresh_derived_fields():
    """Recompute passenger counts, ordered points, and the road-following
    geometry for the CURRENT state.stops ordering. Called after every change."""
    if state.source is None or state.destination is None:
        return

    ordered = [state.source] + [s.point for s in state.stops] + [state.destination]
    state.ordered_points = ordered

    counts = [0]
    running = 0
    for s in state.stops:
        running += 1 if s.kind == "pickup" else -1
        counts.append(running)
    counts.append(0)  # back to 0 at destination conceptually (all dropped by then)
    state.passenger_counts = counts

    leg_matrix = await osrm_client.distance_matrix_km([(p.lat, p.lon) for p in ordered])
    state.leg_distances_km = [round(leg_matrix[i][i + 1], 3) for i in range(len(ordered) - 1)]
    # Keep total_distance_km in sync with the actual current route at all times --
    # including right after /api/setup, before any request has been inserted, when
    # it should be the direct source->destination distance rather than 0. Without
    # this, the first accepted request's last_insertion_cost_km (below) would be
    # computed against a phantom 0 km baseline instead of the real starting route.
    state.total_distance_km = round(sum(state.leg_distances_km), 3)

    state.route_geometry = await osrm_client.route_geometry([(p.lat, p.lon) for p in ordered])


@app.post("/api/setup", response_model=RouteState)
async def setup(req: SetupRequest):
    global state, _next_request_id
    state = RouteState(source=req.source, destination=req.destination, capacity=req.capacity)
    _next_request_id = 1
    await _refresh_derived_fields()
    return state


@app.post("/api/reset", response_model=RouteState)
async def reset():
    global state, _next_request_id
    state = RouteState()
    _next_request_id = 1
    return state


@app.get("/api/state", response_model=RouteState)
async def get_state():
    return state


@app.post("/api/requests", response_model=RouteState)
async def add_request(req: NewRideRequest):
    global _next_request_id

    if state.source is None:
        raise HTTPException(400, "Call /api/setup first (source, destination, capacity).")

    t0 = time.perf_counter()

    # base road distance for this rider's direct pickup -> drop trip
    matrix = await osrm_client.distance_matrix_km([
        (req.pickup.lat, req.pickup.lon),
        (req.drop.lat, req.drop.lon),
    ])
    base_distance_km = matrix[0][1]

    new_id = _next_request_id
    result = await algorithm.find_best_insertion(
        state, new_id, req.pickup, req.drop, base_distance_km, req.flexibility_km
    )

    elapsed_ms = (time.perf_counter() - t0) * 1000
    # 2.7 Output Format requires "Runtime of the algorithm" to be reported.
    # This covers the OSRM matrix fetch + the full insertion search for this
    # request, and is refreshed on every call (accepted or rejected) so the
    # frontend always shows how long the most recent request took to process.
    state.last_insertion_runtime_ms = round(elapsed_ms, 3)

    if not result.feasible:
        state.last_rejection_reason = result.reason
        state.last_insertion_cost_km = None
        return state

    _next_request_id += 1
    state.stops = result.stops
    state.requests.append(RequestRecord(
        id=new_id,
        pickup=req.pickup,
        drop=req.drop,
        base_distance_km=round(base_distance_km, 3),
        flexibility_km=req.flexibility_km,
        max_allowed_km=round(base_distance_km + req.flexibility_km, 3),
    ))
    state.last_insertion_cost_km = round(result.total_distance_km - state.total_distance_km, 3)
    state.total_distance_km = round(result.total_distance_km, 3)
    state.last_rejection_reason = None

    await _refresh_derived_fields()

    return state
