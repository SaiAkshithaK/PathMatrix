import math
import requests

OSRM_TABLE_URL = "https://router.project-osrm.org/table/v1/driving/"


# 1. Haversine — kept as a fallback for when road-distance lookup fails
# (no network, OSRM demo server down/rate-limited, or a pair of points with
# no drivable connection between them, e.g. across water).
def calculate_distance(coord1, coord2):
    lat1, lon1 = coord1
    lat2, lon2 = coord2

    R = 6371.0  # Earth's radius in kilometers

    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lon = math.radians(lon2 - lon1)

    a = math.sin(delta_phi / 2) ** 2 + \
        math.cos(phi1) * math.cos(phi2) * \
        math.sin(delta_lon / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    return R * c


# 2. Road-distance matrix via OSRM's Table service. One HTTP call returns
# every pairwise distance for all points at once (instead of an OSRM Route
# call per pair, which would be slow and would hammer the demo server).
def fetch_road_distance_matrix(coords):
    """
    coords: list of [lat, lon].
    Returns an NxN list of distances in km (matrix[i][j] = road distance
    from coords[i] to coords[j]), or None if the request fails entirely.
    Individual unreachable pairs (e.g. no road connects them) come back as
    None from OSRM and are left as None so the caller can fall back to
    Haversine for just that pair.
    """
    if len(coords) < 2:
        return None

    coord_str = ";".join(f"{lon},{lat}" for lat, lon in coords)
    url = f"{OSRM_TABLE_URL}{coord_str}?annotations=distance"

    try:
        resp = requests.get(url, timeout=15)
        resp.raise_for_status()
        data = resp.json()
        if data.get("code") != "Ok":
            return None
        raw = data["distances"]  # meters
        return [[(d / 1000.0) if d is not None else None for d in row] for row in raw]
    except Exception:
        return None


def _make_dist_fn(coords, matrix):
    """dist(i, j) prefers the road-distance matrix; falls back to Haversine
    for any missing/unreachable/unavailable entry."""
    def dist(i, j):
        if i == j:
            return 0.0
        if matrix is not None:
            v = matrix[i][j]
            if v is not None:
                return v
        return calculate_distance(coords[i], coords[j])
    return dist


# 3. Evaluation Logic — now index-based so it can share the same distance
# matrix/function used during route construction (consistency matters:
# scoring a route with a different distance metric than the one used to
# build it would silently produce misleading satisfaction/budget numbers).
def evaluate_route_satisfaction(route_indices, names, locations_dict, dist_fn, category_threshold=2, k=0.1):
    total_satisfaction = 0.0
    cumulative_distance = 0.0
    category_visit_counts = {}

    for pos in range(len(route_indices) - 1):
        i, j = route_indices[pos], route_indices[pos + 1]
        leg = dist_fn(i, j)

        # Destination earns no sightseeing score. Still add its leg so the
        # returned total distance covers the full route.
        if pos + 1 == len(route_indices) - 1:
            cumulative_distance += leg
            break

        # Decay is based on distance travelled BEFORE reaching this location
        # (per spec: "Cumulative before Museum = 0 km" even though the leg
        # into Museum is 3km) — so score using cumulative_distance BEFORE
        # adding this leg, then advance cumulative_distance afterwards.
        name = names[j]
        base_score = locations_dict[name]["score"]
        category = locations_dict[name]["category"]

        decayed_score = base_score * math.exp(-k * cumulative_distance)
        cumulative_distance += leg

        category_visit_counts[category] = category_visit_counts.get(category, 0) + 1
        if category_visit_counts[category] > category_threshold:
            effective_score = decayed_score * 0.9
        else:
            effective_score = decayed_score

        total_satisfaction += effective_score

    return round(total_satisfaction, 2), round(cumulative_distance, 2)


# 4a. Greedy fallback — kept only for POI counts too large for the exact
# search below to be practical (see GREEDY_FALLBACK_THRESHOLD). Score is
# still computed consistently with evaluate_route_satisfaction's convention:
# decay uses the distance travelled BEFORE the leg into a candidate.
def _greedy_route(start_idx, end_idx, poi_indices, names, locations_dict, dist,
                   max_budget, category_threshold, k):
    current_idx = start_idx
    route_indices = [start_idx]
    total_distance_spent = 0.0
    category_visit_counts = {}
    unvisited = list(poi_indices)

    while unvisited:
        best_idx = None
        best_effective_score = -1
        best_leg_distance = 0

        for idx in unvisited:
            dist_to_spot = dist(current_idx, idx)
            dist_to_end = dist(idx, end_idx)

            if total_distance_spent + dist_to_spot + dist_to_end <= max_budget:
                name = names[idx]
                base_score = locations_dict[name]["score"]
                # Decay uses distance BEFORE this leg, matching the spec.
                decayed_score = base_score * math.exp(-k * total_distance_spent)

                category = locations_dict[name]["category"]
                predicted_visits = category_visit_counts.get(category, 0) + 1
                effective_score = decayed_score * 0.9 if predicted_visits > category_threshold else decayed_score

                if effective_score > best_effective_score:
                    best_effective_score = effective_score
                    best_idx = idx
                    best_leg_distance = dist_to_spot

        if best_idx is None:
            break

        route_indices.append(best_idx)
        total_distance_spent += best_leg_distance
        category = locations_dict[names[best_idx]]["category"]
        category_visit_counts[category] = category_visit_counts.get(category, 0) + 1
        unvisited.remove(best_idx)
        current_idx = best_idx

    route_indices.append(end_idx)
    return route_indices


# 4b. Exact optimizer — bitmask DP over subsets of POIs.
#
# Why greedy isn't enough: picking whichever candidate scores best *right
# now* can strand you with a route that never revisits that choice — e.g.
# it might skip a location it should have detoured to first, because taking
# it later (after more decay) looked worse in the moment. The Hard public
# test cases are built specifically to expose this (TC5/TC6): a greedy pass
# leaves budget unused and lands on a lower total score than the answer key.
#
# The state is (mask, last) — which POIs have been visited and where the
# route currently is. Category counts don't need to be tracked separately;
# they're always derivable from mask, since categories are static per POI.
#
# The subtlety is that satisfaction is not just a function of (mask, last):
# two different visiting orders can reach the same (mask, last) at different
# cumulative distances, and cumulative distance changes future decay. So for
# each (mask, last) we keep a *Pareto frontier* of (distance, satisfaction)
# pairs — a pair is discarded if some other pair reaches the same state with
# both less distance AND at least as much satisfaction (strictly more on one
# of the two), since it can never be worse from that point forward:
# exp(-k*d) is strictly decreasing in d, so lower distance-so-far can only
# help every future pick, and any suffix path is equally available to both.
def _exact_route(start_idx, end_idx, poi_indices, names, locations_dict, dist,
                  max_budget, category_threshold, k):
    n = len(poi_indices)
    # local index 0..n-1 <-> global poi index
    local_of = {g: l for l, g in enumerate(poi_indices)}
    cats = [locations_dict[names[g]]["category"] for g in poi_indices]
    scores = [locations_dict[names[g]]["score"] for g in poi_indices]

    def leg(a, b):
        return dist(a, b)

    def category_count_in_mask(mask, cat_local):
        cat = cats[cat_local]
        count = 0
        m = mask
        while m:
            bit = m & (-m)
            idx = bit.bit_length() - 1
            if cats[idx] == cat:
                count += 1
            m ^= bit
        return count

    # states[(mask, last_local)] = list of dicts: dist, sat, parent(mask,last,idx)
    # last_local == -1 means "still at start"
    states = {(0, -1): [{"dist": 0.0, "sat": 0.0, "parent": None}]}
    order = [(0, -1)]  # states to expand, processed in insertion order (BFS by popcount naturally since we only add supersets)
    seen_order = set(order)

    def add_pareto(key, entry):
        lst = states.setdefault(key, [])
        for e in lst:
            if e["dist"] <= entry["dist"] and e["sat"] >= entry["sat"]:
                return False  # dominated, discard
        lst[:] = [e for e in lst
                  if not (entry["dist"] <= e["dist"] and entry["sat"] >= e["sat"])]
        lst.append(entry)
        return True

    qi = 0
    while qi < len(order):
        mask, last_local = order[qi]
        qi += 1
        last_global = start_idx if last_local == -1 else poi_indices[last_local]

        for entry_idx, entry in enumerate(states[(mask, last_local)]):
            base_dist = entry["dist"]
            base_sat = entry["sat"]

            for cand_local in range(n):
                bit = 1 << cand_local
                if mask & bit:
                    continue
                cand_global = poi_indices[cand_local]
                dist_to_cand = leg(last_global, cand_global)
                dist_to_end = leg(cand_global, end_idx)
                new_dist = base_dist + dist_to_cand
                if new_dist + dist_to_end > max_budget:
                    continue  # infeasible: could never reach the end afterwards

                visits = category_count_in_mask(mask, cand_local) + 1
                decayed = scores[cand_local] * math.exp(-k * base_dist)
                effective = decayed * 0.9 if visits > category_threshold else decayed
                new_sat = base_sat + effective
                new_mask = mask | bit
                new_key = (new_mask, cand_local)

                added = add_pareto(new_key, {
                    "dist": new_dist, "sat": new_sat,
                    "parent": (mask, last_local, entry_idx),
                })
                if added and new_key not in seen_order:
                    order.append(new_key)
                    seen_order.add(new_key)

    # Pick the best finishing state: maximise satisfaction, tie-break on
    # shorter total distance.
    best = None  # (sat, -dist, key, entry_idx, final_dist)
    for (mask, last_local), lst in states.items():
        last_global = start_idx if last_local == -1 else poi_indices[last_local]
        final_leg = leg(last_global, end_idx)
        for entry_idx, entry in enumerate(lst):
            final_dist = entry["dist"] + final_leg
            if final_dist > max_budget:
                continue
            candidate = (entry["sat"], -final_dist, (mask, last_local), entry_idx, final_dist)
            if best is None or (candidate[0], candidate[1]) > (best[0], best[1]):
                best = candidate

    if best is None:
        # No POI is reachable within budget at all — direct start->end.
        return [start_idx, end_idx]

    # Reconstruct path by walking parent pointers back to (0, -1).
    _, _, key, entry_idx, _ = best
    path_locals = []
    cur_key, cur_idx = key, entry_idx
    while cur_key != (0, -1):
        mask, last_local = cur_key
        entry = states[cur_key][cur_idx]
        path_locals.append(last_local)
        parent = entry["parent"]
        cur_key = (parent[0], parent[1])
        cur_idx = parent[2]
    path_locals.reverse()

    route_indices = [start_idx] + [poi_indices[l] for l in path_locals] + [end_idx]
    return route_indices


# Beyond this many POIs, the exact DP's state space (2^n subsets, each
# possibly holding several Pareto-frontier entries) stops being practical
# for an interactive web request, so we fall back to the greedy heuristic.
# Benchmarked on random inputs: ~0.1s at 10 POIs, ~0.9s at 12, ~55s at 16 —
# the Pareto frontier can grow large when many candidate distances are
# close together, so this is kept conservative. The assignment's largest
# published test case uses 6 POIs, well inside this bound.
GREEDY_FALLBACK_THRESHOLD = 12


def optimize_sightseeing_route(start_name, start_coords, end_name, end_coords, locations_dict,
                                max_budget, category_threshold=2, k=0.1, use_road_distance=True):
    poi_names = list(locations_dict.keys())
    names = [start_name] + poi_names + [end_name]
    coords = [start_coords] + [locations_dict[n]["coords"] for n in poi_names] + [end_coords]

    start_idx = 0
    end_idx = len(names) - 1
    poi_indices = list(range(1, end_idx))

    matrix = fetch_road_distance_matrix(coords) if use_road_distance else None
    used_road_distance = matrix is not None
    dist = _make_dist_fn(coords, matrix)

    if len(poi_indices) <= GREEDY_FALLBACK_THRESHOLD:
        route_indices = _exact_route(start_idx, end_idx, poi_indices, names, locations_dict, dist,
                                      max_budget, category_threshold, k)
    else:
        route_indices = _greedy_route(start_idx, end_idx, poi_indices, names, locations_dict, dist,
                                       max_budget, category_threshold, k)

    final_score, final_dist = evaluate_route_satisfaction(
        route_indices, names, locations_dict, dist, category_threshold, k
    )

    route_names = [names[i] for i in route_indices]
    return route_names, final_score, final_dist, used_road_distance
