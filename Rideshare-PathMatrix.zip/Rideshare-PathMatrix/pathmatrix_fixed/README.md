# PathMatrix Global - Sightseeing Route Optimizer (Part A)

PathMatrix Global is an interactive, web-based map routing application designed to help travelers plan optimized sightseeing tours. By taking user inputs such as starting city, ending destination, a maximum distance budget, and decay settings, the backend dynamically calculates and plots the most efficient tour path while showcasing localized points of interest along the route.

---

## 📁 Folder Structure

```text
pathmatrix_fixed/
├── templates/
│   └── map.html       # Frontend map interface (Leaflet.js + HTML/JS)
├── app.py             # Main Flask backend application
├── part_a.py          # Core pathfinding and matrix logic for Part A
└── part_b.py          # Additional route optimization helper algorithms