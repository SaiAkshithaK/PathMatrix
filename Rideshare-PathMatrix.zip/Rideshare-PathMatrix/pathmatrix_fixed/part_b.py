import math
from part_a import calculate_distance

def insert_new_request(current_route_names, current_route_coords, locations_dict, pickup_coords, dropoff_coords, max_budget, current_capacity, max_capacity=2):
    """
    Attempts to insert a real-time ride-sharing request (Pickup -> Dropoff) 
    into the existing sightseeing tour itinerary without violating the distance budget 
    or maximum vehicle passenger capacity.
    """
    # 1. Check basic vehicle seating constraints
    if current_capacity >= max_capacity:
        return {
            "status": "rejected",
            "reason": f"Vehicle capacity exceeded! (Current: {current_capacity}/{max_capacity})"
        }
        
    # We can only insert points between existing stops.
    # A route always has at least a Start Point (index 0) and End Point (index len-1)
    best_route_names = None
    best_total_distance = float('inf')
    
    n = len(current_route_names)
    
    # 2. Heuristic Search: Try inserting Pickup at position 'i' and Drop-off at position 'j'
    # 'i' can range from 1 (right after start) up to 'n'
    for i in range(1, n):
        for j in range(i, n + 1):
            # Reconstruct a candidate sequence copy
            temp_names = list(current_route_names)
            temp_coords = list(current_route_coords)
            
            # Insert Drop-off first if j > i, otherwise order matters
            temp_names.insert(j, "Passenger Drop-off")
            temp_coords.insert(j, dropoff_coords)
            
            temp_names.insert(i, "Passenger Pickup")
            temp_coords.insert(i, pickup_coords)
            
            # Calculate the total distance of this new proposed path combination
            candidate_distance = 0.0
            for k in range(len(temp_coords) - 1):
                candidate_distance += calculate_distance(temp_coords[k], temp_coords[k+1])
                
            # If it fits within the budget bounds and is shorter than previous iterations
            if candidate_distance <= max_budget and candidate_distance < best_total_distance:
                best_total_distance = round(candidate_distance, 2)
                best_route_names = temp_names

    if best_route_names:
        return {
            "status": "accepted",
            "route": best_route_names,
            "distance": best_total_distance,
            "reason": "Request successfully pooled into the itinerary!"
        }
    else:
        return {
            "status": "rejected",
            "reason": "Detour exceeds remaining travel distance budget limit."
        }