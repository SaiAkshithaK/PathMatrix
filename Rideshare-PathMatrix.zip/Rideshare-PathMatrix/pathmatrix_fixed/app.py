from flask import Flask, render_template, jsonify, request
from part_a import optimize_sightseeing_route
from part_b import insert_new_request

app = Flask(__name__)

# Temporary global state storage to remember the last optimized route sequence
last_computed_route = {
    "names": [],
    "coords": []
}

@app.route('/')
def home():
    return render_template('map.html')

@app.route('/api/optimize_tour', methods=['POST'])
def optimize_tour():
    data = request.json or {}
    budget = float(data.get('budget', 100))
    threshold = int(data.get('threshold', 2))
    decay_k = float(data.get('decay_k', 0.05))
    start_coords = data.get('start_coords')
    end_coords = data.get('end_coords')
    custom_locations = data.get('locations', {})
    
    route_names, score, distance, used_road_distance = optimize_sightseeing_route(
        start_name="Start Point", start_coords=start_coords,
        end_name="End Point", end_coords=end_coords,
        locations_dict=custom_locations, max_budget=budget,
        category_threshold=threshold, k=decay_k
    )
    
    # Reconstruct array tracking system state coords
    route_coords = []
    for name in route_names:
        if name == "Start Point": route_coords.append(start_coords)
        elif name == "End Point": route_coords.append(end_coords)
        else: route_coords.append(custom_locations[name]["coords"])
        
    last_computed_route["names"] = route_names
    last_computed_route["coords"] = route_coords
    
    return jsonify({
        "status": "success", "route": route_names, "score": score, "distance": distance,
        "distance_source": "road" if used_road_distance else "straight-line (road API unavailable)"
    })

@app.route('/api/insert_ride', methods=['POST'])
def insert_ride():
    data = request.json or {}
    
    if not last_computed_route["names"]:
        return jsonify({"status": "error", "message": "Please optimize a tour route first!"})
        
    pickup = data.get('pickup')
    dropoff = data.get('dropoff')
    budget = float(data.get('budget', 100))
    capacity = int(data.get('capacity', 0))
    locations = data.get('locations', {})
    
    result = insert_new_request(
        current_route_names=last_computed_route["names"],
        current_route_coords=last_computed_route["coords"],
        locations_dict=locations,
        pickup_coords=pickup,
        dropoff_coords=dropoff,
        max_budget=budget,
        current_capacity=capacity,
        max_capacity=2
    )
    
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True, port=5000)